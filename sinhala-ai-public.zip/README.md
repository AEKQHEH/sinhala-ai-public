# Sinhala AI Bot
A simple Sinhala voice-based AI chatbot using Python.
